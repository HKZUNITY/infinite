﻿/**
 * AUTO GENERATE BY UI EDITOR.
 * WARNING: DO NOT MODIFY THIS FILE,MAY CAUSE CODE LOST.
 * AUTHOR: 爱玩游戏的小胖子
 * UI: UI/module/LotteryModule/LotteryResultPanel.ui
 * TIME: 2024.09.28-02.16.44
 */
 
@UIBind('UI/module/LotteryModule/LotteryResultPanel.ui')
export default class LotteryResultPanel_Generate extends UIScript {
		private mCloseButton_Internal: mw.Button
	public get mCloseButton(): mw.Button {
		if(!this.mCloseButton_Internal&&this.uiWidgetBase) {
			this.mCloseButton_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/BgImage/mCloseButton') as mw.Button
		}
		return this.mCloseButton_Internal
	}
	private mContentCanvas_Internal: mw.Canvas
	public get mContentCanvas(): mw.Canvas {
		if(!this.mContentCanvas_Internal&&this.uiWidgetBase) {
			this.mContentCanvas_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas') as mw.Canvas
		}
		return this.mContentCanvas_Internal
	}
	private mImage_0_Internal: mw.Image
	public get mImage_0(): mw.Image {
		if(!this.mImage_0_Internal&&this.uiWidgetBase) {
			this.mImage_0_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_0') as mw.Image
		}
		return this.mImage_0_Internal
	}
	private mTextBlock_0_Internal: mw.TextBlock
	public get mTextBlock_0(): mw.TextBlock {
		if(!this.mTextBlock_0_Internal&&this.uiWidgetBase) {
			this.mTextBlock_0_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_0/mTextBlock_0') as mw.TextBlock
		}
		return this.mTextBlock_0_Internal
	}
	private mImage_1_Internal: mw.Image
	public get mImage_1(): mw.Image {
		if(!this.mImage_1_Internal&&this.uiWidgetBase) {
			this.mImage_1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_1') as mw.Image
		}
		return this.mImage_1_Internal
	}
	private mTextBlock_1_Internal: mw.TextBlock
	public get mTextBlock_1(): mw.TextBlock {
		if(!this.mTextBlock_1_Internal&&this.uiWidgetBase) {
			this.mTextBlock_1_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_1/mTextBlock_1') as mw.TextBlock
		}
		return this.mTextBlock_1_Internal
	}
	private mImage_2_Internal: mw.Image
	public get mImage_2(): mw.Image {
		if(!this.mImage_2_Internal&&this.uiWidgetBase) {
			this.mImage_2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_2') as mw.Image
		}
		return this.mImage_2_Internal
	}
	private mTextBlock_2_Internal: mw.TextBlock
	public get mTextBlock_2(): mw.TextBlock {
		if(!this.mTextBlock_2_Internal&&this.uiWidgetBase) {
			this.mTextBlock_2_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_2/mTextBlock_2') as mw.TextBlock
		}
		return this.mTextBlock_2_Internal
	}
	private mImage_3_Internal: mw.Image
	public get mImage_3(): mw.Image {
		if(!this.mImage_3_Internal&&this.uiWidgetBase) {
			this.mImage_3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_3') as mw.Image
		}
		return this.mImage_3_Internal
	}
	private mTextBlock_3_Internal: mw.TextBlock
	public get mTextBlock_3(): mw.TextBlock {
		if(!this.mTextBlock_3_Internal&&this.uiWidgetBase) {
			this.mTextBlock_3_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_3/mTextBlock_3') as mw.TextBlock
		}
		return this.mTextBlock_3_Internal
	}
	private mImage_4_Internal: mw.Image
	public get mImage_4(): mw.Image {
		if(!this.mImage_4_Internal&&this.uiWidgetBase) {
			this.mImage_4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_4') as mw.Image
		}
		return this.mImage_4_Internal
	}
	private mTextBlock_4_Internal: mw.TextBlock
	public get mTextBlock_4(): mw.TextBlock {
		if(!this.mTextBlock_4_Internal&&this.uiWidgetBase) {
			this.mTextBlock_4_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_4/mTextBlock_4') as mw.TextBlock
		}
		return this.mTextBlock_4_Internal
	}
	private mImage_5_Internal: mw.Image
	public get mImage_5(): mw.Image {
		if(!this.mImage_5_Internal&&this.uiWidgetBase) {
			this.mImage_5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_5') as mw.Image
		}
		return this.mImage_5_Internal
	}
	private mTextBlock_5_Internal: mw.TextBlock
	public get mTextBlock_5(): mw.TextBlock {
		if(!this.mTextBlock_5_Internal&&this.uiWidgetBase) {
			this.mTextBlock_5_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_5/mTextBlock_5') as mw.TextBlock
		}
		return this.mTextBlock_5_Internal
	}
	private mImage_6_Internal: mw.Image
	public get mImage_6(): mw.Image {
		if(!this.mImage_6_Internal&&this.uiWidgetBase) {
			this.mImage_6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_6') as mw.Image
		}
		return this.mImage_6_Internal
	}
	private mTextBlock_6_Internal: mw.TextBlock
	public get mTextBlock_6(): mw.TextBlock {
		if(!this.mTextBlock_6_Internal&&this.uiWidgetBase) {
			this.mTextBlock_6_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_6/mTextBlock_6') as mw.TextBlock
		}
		return this.mTextBlock_6_Internal
	}
	private mImage_7_Internal: mw.Image
	public get mImage_7(): mw.Image {
		if(!this.mImage_7_Internal&&this.uiWidgetBase) {
			this.mImage_7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_7') as mw.Image
		}
		return this.mImage_7_Internal
	}
	private mTextBlock_7_Internal: mw.TextBlock
	public get mTextBlock_7(): mw.TextBlock {
		if(!this.mTextBlock_7_Internal&&this.uiWidgetBase) {
			this.mTextBlock_7_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_7/mTextBlock_7') as mw.TextBlock
		}
		return this.mTextBlock_7_Internal
	}
	private mImage_8_Internal: mw.Image
	public get mImage_8(): mw.Image {
		if(!this.mImage_8_Internal&&this.uiWidgetBase) {
			this.mImage_8_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_8') as mw.Image
		}
		return this.mImage_8_Internal
	}
	private mTextBlock_8_Internal: mw.TextBlock
	public get mTextBlock_8(): mw.TextBlock {
		if(!this.mTextBlock_8_Internal&&this.uiWidgetBase) {
			this.mTextBlock_8_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_8/mTextBlock_8') as mw.TextBlock
		}
		return this.mTextBlock_8_Internal
	}
	private mImage_9_Internal: mw.Image
	public get mImage_9(): mw.Image {
		if(!this.mImage_9_Internal&&this.uiWidgetBase) {
			this.mImage_9_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_9') as mw.Image
		}
		return this.mImage_9_Internal
	}
	private mTextBlock_9_Internal: mw.TextBlock
	public get mTextBlock_9(): mw.TextBlock {
		if(!this.mTextBlock_9_Internal&&this.uiWidgetBase) {
			this.mTextBlock_9_Internal = this.uiWidgetBase.findChildByPath('RootCanvas/MainCanvas/BgCanvas/mContentCanvas/mImage_9/mTextBlock_9') as mw.TextBlock
		}
		return this.mTextBlock_9_Internal
	}


	protected onAwake() {
		//设置能否每帧触发onUpdate
		this.canUpdate = false;
		this.layer = mw.UILayerBottom;
		this.initButtons();
	}
	protected initButtons() {
		//按钮添加点击
		
		//按钮添加点击
		
		this.mCloseButton.onClicked.add(()=>{
			Event.dispatchToLocal("PlayButtonClick", "mCloseButton");
		});
		this.mCloseButton.touchMethod = (mw.ButtonTouchMethod.PreciseTap);
		
	
		//按钮多语言
		
		//文本多语言
		
		this.initLanguage(this.mTextBlock_0)
		
	
		this.initLanguage(this.mTextBlock_1)
		
	
		this.initLanguage(this.mTextBlock_2)
		
	
		this.initLanguage(this.mTextBlock_3)
		
	
		this.initLanguage(this.mTextBlock_4)
		
	
		this.initLanguage(this.mTextBlock_5)
		
	
		this.initLanguage(this.mTextBlock_6)
		
	
		this.initLanguage(this.mTextBlock_7)
		
	
		this.initLanguage(this.mTextBlock_8)
		
	
		this.initLanguage(this.mTextBlock_9)
		
	
		//文本多语言
		
	}
	
	/*初始化多语言*/
	private initLanguage(ui: mw.StaleButton | mw.TextBlock) {
        let call = mw.UIScript.getBehavior("lan");
        if (call && ui) {
            call(ui);
        }
    }

	protected onShow(...params: any[]): void {};

	/*显示panel*/
    public show(...param): void {
		mw.UIService.showUI(this, this.layer, ...param);
	}

	/*隐藏panel*/
    public hide(): void {
		mw.UIService.hideUI(this);
	}
 }
 