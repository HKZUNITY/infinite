// import AdsModuleC from "./AdsModuleC";

// export default class AdsModuleS extends ModuleS<AdsModuleC, null>{

//     /** 当脚本被实例后，会在第一帧更新前调用此函数 */
//     protected onStart(): void {

//     }
// }