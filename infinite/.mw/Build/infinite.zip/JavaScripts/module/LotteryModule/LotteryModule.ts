﻿import { Notice } from "../../common/notice/Notice";
import { GameConfig } from "../../config/GameConfig";
import GlobalData from "../../const/GlobalData";
import { Utils } from "../../Tools/utils";
import LotteryItem_Generate from "../../ui-generate/module/LotteryModule/LotteryItem_generate";
import LotteryPanel_Generate from "../../ui-generate/module/LotteryModule/LotteryPanel_generate";
import LotteryResultItem_Generate from "../../ui-generate/module/LotteryModule/LotteryResultItem_generate";
import LotteryResultPanel_Generate from "../../ui-generate/module/LotteryModule/LotteryResultPanel_generate";
import { BagModuleC } from "../BagModule/BagModule";
import HUDModuleC from "../HUDModule/HUDModuleC";
import HUDPanel from "../HUDModule/ui/HUDPanel";
import { LevelItem } from "../LevelModule/LevelModule";
import PlayerModuleC from "../PlayerModule/PlayerModuleC";

export enum RewardType {
    None,
    Diamond,
    Lv,
    Bag
}

export const lotteryDatas: Map<number, { isLimit: boolean, ratio: number[], icon: string, name: string, rewardType: RewardType, reward: number, pos: mw.Vector2, bgIcon: string }> = new Map<number, { isLimit: boolean, ratio: number[], icon: string, name: string, rewardType: RewardType, reward: number, pos: mw.Vector2, bgIcon: string }>();
lotteryDatas.set(1, { isLimit: false, ratio: [1, 500], icon: "icon_404083", name: `Text_EmptyPrizeHaha`, rewardType: RewardType.None, reward: 1, pos: new mw.Vector2(0, 0), bgIcon: "181426" });//181426 181425 181424 181423 181420
lotteryDatas.set(2, { isLimit: false, ratio: [501, 739], icon: "icon_103221", name: `Text_Diamonds`, rewardType: RewardType.Diamond, reward: 1, pos: new mw.Vector2(230, 0), bgIcon: "181424" });
lotteryDatas.set(3, { isLimit: false, ratio: [740, 749], icon: "icon_103221", name: `Text_Diamonds`, rewardType: RewardType.Diamond, reward: 108, pos: new mw.Vector2(460, 0), bgIcon: "181423" });
lotteryDatas.set(4, { isLimit: false, ratio: [750, 750], icon: "icon_103217", name: `Text_Diamonds`, rewardType: RewardType.Diamond, reward: 1088, pos: new mw.Vector2(690, 0), bgIcon: "181420" });
lotteryDatas.set(5, { isLimit: false, ratio: [751, 978], icon: "icon_148883", name: `Text_Grade`, rewardType: RewardType.Lv, reward: 1, pos: new mw.Vector2(690, 230), bgIcon: "181424" });
lotteryDatas.set(6, { isLimit: false, ratio: [979, 988], icon: "icon_148883", name: `Text_Grade`, rewardType: RewardType.Lv, reward: 108, pos: new mw.Vector2(690, 460), bgIcon: "181423" });
lotteryDatas.set(7, { isLimit: false, ratio: [989, 989], icon: "icon_148883", name: `Text_Grade`, rewardType: RewardType.Lv, reward: 1088, pos: new mw.Vector2(460, 460), bgIcon: "181420" });
lotteryDatas.set(8, { isLimit: true, ratio: [990, 995], icon: "mode_141499", name: `Text_GodLevelDemonKing`, rewardType: RewardType.Bag, reward: 20058, pos: new mw.Vector2(230, 460), bgIcon: "181420" });
lotteryDatas.set(9, { isLimit: true, ratio: [996, 999], icon: "mode_142921", name: `Text_TheFourthHokage`, rewardType: RewardType.Bag, reward: 20059, pos: new mw.Vector2(0, 460), bgIcon: "181420" });
lotteryDatas.set(10, { isLimit: true, ratio: [1000, 1000], icon: "mode_163289", name: `Text_MedusaQueen`, rewardType: RewardType.Bag, reward: 20060, pos: new mw.Vector2(0, 230), bgIcon: "181420" });
const oneCostCoin: number = 2888888;
const oneCostArk: number = 2;
const tenCostCoin: number = 28888888;
const tenCostArk: number = 20;
const hundredCostCoin: number = 8888888888;
const hundredCostArk: number = 200;
const oneCommodityId: string = "7I6uNtkFmg00001Nx";
const tenCommodityId: string = "6tOZfQYVTV90001Ny";
const hundredCommodityId: string = "3FClUXv0qbL0001Pq";

export class LotteryItem extends LotteryItem_Generate {
    private lotteryModuleC: LotteryModuleC = null;
    private get getLotteryModuleC(): LotteryModuleC {
        if (!this.lotteryModuleC) {
            this.lotteryModuleC = ModuleService.getModule(LotteryModuleC);
        }
        return this.lotteryModuleC;
    }

    protected onStart(): void {
        this.initUI();
    }

    private initUI(): void {
        this.mHasTextBlock.text = GameConfig.Language.Text_AlreadyOwned.Value;
        this.onOffUI(false);

        if (GlobalData.languageId == 0) {
            this.mRewardTextBlock.fontSize = 12;
            this.mRatioTextBlock.fontSize = 13;
        } else {
            this.mRewardTextBlock.fontSize = 23;
            this.mRatioTextBlock.fontSize = 15;
        }
    }

    private key: number = 0;
    public initItem(key: number): void {
        this.key = key;
        this.updateUI();
    }

    private updateUI(): void {
        let lotteryData = lotteryDatas.get(this.key);
        this.mBgImage.imageGuid = lotteryData.bgIcon;
        this.mRewardTextBlock.text = `${GameConfig.Language[`${lotteryData.name}`].Value}+${(lotteryData.rewardType == RewardType.Bag) ? 1 : lotteryData.reward}`;
        let iconStr = lotteryData.icon.split(`_`);
        if (iconStr[0] == `icon`) {
            this.mIconImage.imageGuid = iconStr[1];
        } else if (iconStr[0] == `mode`) {
            Utils.setImageByAssetIconData(this.mIconImage, iconStr[1]);
        }
        if (lotteryData.isLimit && this.getLotteryModuleC.isHas(lotteryData.reward)) {
            this.mHasCanvas.visibility = mw.SlateVisibility.SelfHitTestInvisible;
        } else {
            this.mHasCanvas.visibility = mw.SlateVisibility.Collapsed;
        }
        this.mRatioTextBlock.text = `${GameConfig.Language.Text_WinningProbability.Value}\n${(((lotteryData.ratio[1] - lotteryData.ratio[0] + 1) / 1000) * 100).toFixed(1)}%`;
    }

    public onOffUI(on: boolean): void {
        this.mSelectImage.visibility = on ? mw.SlateVisibility.SelfHitTestInvisible : mw.SlateVisibility.Collapsed;
    }

    public setHasCanvas(on: boolean): void {
        this.mHasCanvas.visibility = on ? mw.SlateVisibility.SelfHitTestInvisible : mw.SlateVisibility.Collapsed;
    }
}

export class LotteryPanel extends LotteryPanel_Generate {
    private lotteryModuleC: LotteryModuleC = null;
    private get getLotteryModuleC(): LotteryModuleC {
        if (!this.lotteryModuleC) {
            this.lotteryModuleC = ModuleService.getModule(LotteryModuleC);
        }
        return this.lotteryModuleC;
    }

    protected onStart(): void {
        this.initUI();
        this.bindButton();
    }

    private initUI(): void {
        this.mTitleTextBlock.text = GameConfig.Language.Text_GoldCoinLottery.Value;

        this.mIconCoinImage.imageGuid = GlobalData.coinIcon;
        this.mIconArkImage.imageGuid = GlobalData.arkIcon;

        this.mOneCoinTextBlock.text = StringUtil.format(GameConfig.Language.Text_DrawTimes.Value, 1);
        this.mOneCoinTipsTextBlock.text = StringUtil.format(GameConfig.Language.Text_ConsumeCoins.Value, oneCostCoin);

        this.mOneArkTextBlock.text = StringUtil.format(GameConfig.Language.Text_DrawTimes.Value, 1);
        this.mOneArkTipsTextBlock.text = StringUtil.format(GameConfig.Language.Text_ConsumeDispatchCoins.Value, oneCostArk);

        this.mTenCoinTextBlock.text = StringUtil.format(GameConfig.Language.Text_DrawTimes.Value, 10);
        this.mTenCoinTipsTextBlock.text = StringUtil.format(GameConfig.Language.Text_ConsumeCoins.Value, tenCostCoin);

        this.mTenArkTextBlock.text = StringUtil.format(GameConfig.Language.Text_DrawTimes.Value, 10);
        this.mTenArkTipsTextBlock.text = StringUtil.format(GameConfig.Language.Text_ConsumeDispatchCoins.Value, tenCostArk);

        this.mHundredCoinTextBlock.text = StringUtil.format(GameConfig.Language.Text_DrawTimes.Value, 100);
        this.mHundredCoinTipsTextBlock.text = StringUtil.format(GameConfig.Language.Text_ConsumeCoins.Value, hundredCostCoin);

        this.mHundredArkTextBlock.text = StringUtil.format(GameConfig.Language.Text_DrawTimes.Value, 100);
        this.mHundredArkTipsTextBlock.text = StringUtil.format(GameConfig.Language.Text_ConsumeDispatchCoins.Value, hundredCostArk);

        this.mOneAdsButton.text = GameConfig.Language.Text_FreeLotteryDraw.Value;

        this.mMaskImage.visibility = mw.SlateVisibility.Collapsed;
        this.initItem();

        if (GlobalData.languageId == 0) {
            this.mOneCoinTextBlock.fontSize = 20;
            this.mOneCoinTipsTextBlock.fontSize = 10;

            this.mOneArkTextBlock.fontSize = 20;
            this.mOneArkTipsTextBlock.fontSize = 17;

            this.mTenCoinTextBlock.fontSize = 20;
            this.mTenCoinTipsTextBlock.fontSize = 10;

            this.mTenArkTextBlock.fontSize = 20;
            this.mTenArkTipsTextBlock.fontSize = 15;

            this.mHundredCoinTextBlock.fontSize = 20;
            this.mHundredCoinTipsTextBlock.fontSize = 12;

            this.mHundredArkTextBlock.fontSize = 20;
            this.mHundredArkTipsTextBlock.fontSize = 15;

        } else {
            this.mOneCoinTextBlock.fontSize = 30;
            this.mOneCoinTipsTextBlock.fontSize = 18;

            this.mOneArkTextBlock.fontSize = 30;
            this.mOneArkTipsTextBlock.fontSize = 20;

            this.mTenCoinTextBlock.fontSize = 30;
            this.mTenCoinTipsTextBlock.fontSize = 15;

            this.mTenArkTextBlock.fontSize = 30;
            this.mTenArkTipsTextBlock.fontSize = 20;

            this.mHundredCoinTextBlock.fontSize = 30;
            this.mHundredCoinTipsTextBlock.fontSize = 14;

            this.mHundredArkTextBlock.fontSize = 30;
            this.mHundredArkTipsTextBlock.fontSize = 20;
        }
    }

    private isCanContinueClick: boolean = true;
    private bindButton(): void {
        this.mCloseButton.onClicked.add(this.addCloseButton.bind(this));
        this.mOneCoinButton.onClicked.add(this.addOneCoinButton.bind(this));
        this.mOneArkButton.onClicked.add(this.addOneArkButton.bind(this));

        this.mTenCoinButton.onClicked.add(this.addTenCoinButton.bind(this));
        this.mTenArkButton.onClicked.add(this.addTenArkButton.bind(this));

        this.mHundredCoinButton.onClicked.add(this.addHundredCoinButton.bind(this));
        this.mHundredArkButton.onClicked.add(this.addHundredArkButton.bind(this));

        this.mOneAdsButton.onClose.add(this.addOneAdsButton.bind(this));
    }

    private addOneCoinButton(): void {
        this.getLotteryModuleC.oneCoinLottery();
    }

    private addOneArkButton(): void {
        if (!this.isCanContinueClick) {
            Notice.showDownNotice(StringUtil.format(GameConfig.Language.Text_CoolForSeconds.Value, 3));
            return;
        }
        this.isCanContinueClick = false;
        TimeUtil.delaySecond(3).then(() => {
            this.isCanContinueClick = true;
        });
        this.getLotteryModuleC.oneArkLottery();
    }

    private addTenCoinButton(): void {
        this.getLotteryModuleC.tenCoinLottery(true);
    }

    private addTenArkButton(): void {
        if (!this.isCanContinueClick) {
            Notice.showDownNotice(StringUtil.format(GameConfig.Language.Text_CoolForSeconds.Value, 3));
            return;
        }
        this.isCanContinueClick = false;
        TimeUtil.delaySecond(3).then(() => {
            this.isCanContinueClick = true;
        });
        this.getLotteryModuleC.tenArkLottery(true);
    }

    private addHundredCoinButton(): void {
        this.getLotteryModuleC.tenCoinLottery(false);
    }

    private addHundredArkButton(): void {
        if (!this.isCanContinueClick) {
            Notice.showDownNotice(StringUtil.format(GameConfig.Language.Text_CoolForSeconds.Value, 3));
            return;
        }
        this.isCanContinueClick = false;
        TimeUtil.delaySecond(3).then(() => {
            this.isCanContinueClick = true;
        });
        this.getLotteryModuleC.tenArkLottery(false);
    }

    private addOneAdsButton(isSuccess: boolean): void {
        if (!isSuccess) {
            Notice.showDownNotice(GameConfig.Language.Text_FailedPleaseTryAgain.Value);
            return;
        }
        this.getLotteryModuleC.calculateOneLottery();
    }

    private addCloseButton(): void {
        this.hideTween();
    }

    private lotteryItems: LotteryItem[] = [];
    private initItem(): void {
        lotteryDatas.forEach((value: {
            isLimit: boolean;
            ratio: number[];
            icon: string;
            name: string;
            rewardType: RewardType;
            reward: number;
            pos: mw.Vector2;
            bgIcon: string;
        }, key: number) => {
            let lotteryItem = mw.UIService.create(LotteryItem);
            lotteryItem.initItem(key);
            this.mCanvas.addChild(lotteryItem.uiObject);
            lotteryItem.uiObject.position = value.pos;
            this.lotteryItems.push(lotteryItem);
        });
    }

    public updateCoinTextBlock(count: number): void {
        this.mCoinCountTextBlock.text = Utils.integerUnitConversionStr(count);
    }

    public updateArkTextBlock(arkCount: number): void {
        this.mArkCountTextBlock.text = `${arkCount}`;
    }

    public updateItemHasState(key: number): void {
        if (this.lotteryItems.length <= key) {
            this.lotteryItems[key - 1].setHasCanvas(true);
        }
    }

    private oneIndex: number = 0;
    private onePeriod: number = 0;
    public startOneLottery(key: number, complete: () => void): void {
        this.mMaskImage.visibility = mw.SlateVisibility.Visible;
        this.oneIndex = 0;
        this.onePeriod = 0;

        let first = TimeUtil.setInterval(() => {
            if (this.oneIndex >= 10) {
                this.oneIndex = 0;
                this.onePeriod++;
                if (this.onePeriod >= 4) {
                    SoundService.playSound("120847");
                    this.updateItemSelectState(this.oneIndex++);
                    TimeUtil.clearInterval(first);
                    if (key == 1) {
                        if (complete) complete();
                        this.mMaskImage.visibility = mw.SlateVisibility.Collapsed;
                    } else {
                        let second = TimeUtil.setInterval(() => {
                            if (this.oneIndex >= key) {
                                TimeUtil.clearInterval(second);
                                if (complete) complete();
                                this.mMaskImage.visibility = mw.SlateVisibility.Collapsed;
                            } else {
                                this.updateItemSelectState(this.oneIndex++);
                                SoundService.playSound("120847");
                            }
                        }, 0.3);
                    }
                    return;
                }
            }

            SoundService.playSound("120847");
            this.updateItemSelectState(this.oneIndex++);
        }, 0.1);
    }

    public startTenLottery(key: number[], complete: () => void): void {
        this.mMaskImage.visibility = mw.SlateVisibility.Visible;

        let time: number = 0;
        let indexs: number[] = Utils.getRandomArr([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 5);
        for (let i = 0; i < this.lotteryItems.length; ++i) {
            if (indexs.includes(i)) {
                this.lotteryItems[i].onOffUI(true);
            } else {
                this.lotteryItems[i].onOffUI(false);
            }
        }
        SoundService.playSound("137566");
        let first = TimeUtil.setInterval(() => {
            let indexs: number[] = Utils.getRandomArr([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 5);
            for (let i = 0; i < this.lotteryItems.length; ++i) {
                if (indexs.includes(i)) {
                    this.lotteryItems[i].onOffUI(true);
                } else {
                    this.lotteryItems[i].onOffUI(false);
                }
            }
            SoundService.playSound("137566");
            time += 0.3;
            if (time >= 5) {
                TimeUtil.clearInterval(first);
                SoundService.playSound("137566");
                for (let i = 0; i < this.lotteryItems.length; ++i) {
                    if (key.includes((i + 1))) {
                        this.lotteryItems[i].onOffUI(true);
                    } else {
                        this.lotteryItems[i].onOffUI(false);
                    }
                }
                if (complete) complete();
                this.mMaskImage.visibility = mw.SlateVisibility.Collapsed;
            }
        }, 0.3);
    }

    private preIndex: number = -1;
    private updateItemSelectState(index: number): void {
        if (this.preIndex >= 0) this.lotteryItems[this.preIndex].onOffUI(false);
        this.preIndex = index;
        this.lotteryItems[this.preIndex].onOffUI(true);
    }

    private hudPanel: HUDPanel = null;
    private get getHudPanel(): HUDPanel {
        if (!this.hudPanel) {
            this.hudPanel = mw.UIService.getUI(HUDPanel);
        }
        return this.hudPanel
    }

    protected onShow(...params: any[]): void {
        Utils.openUITween(
            this.rootCanvas,
            () => {
                this.getHudPanel.hide();
            },
            null
        );
    }

    public hideTween(): void {
        Utils.closeUITween(
            this.rootCanvas,
            null,
            () => {
                this.hide();
                this.getHudPanel.show();
            });
    }
}

export class LotteryResultItem extends LotteryResultItem_Generate {
    protected onStart(): void {

    }

    public setTextBlock(key: number): void {
        this.mTextBlock.text = `${GameConfig.Language[`${lotteryDatas.get(key).name}`].Value} +${lotteryDatas.get(key).reward}`;
    }
}

export class LotteryResultPanel extends LotteryResultPanel_Generate {
    protected onStart(): void {
        this.layer = mw.UILayerMiddle;
        this.bindButton();
        this.initTextBlock();
    }

    private initTextBlock(): void {
        this.mTitleTextBlock.text = GameConfig.Language.Text_LotteryResults.Value;
    }

    private bindButton(): void {
        this.mCloseButton.onClicked.add(this.addCloseButton.bind(this));
    }

    private addCloseButton(): void {
        this.hide();
    }

    private lotteryResultItems: LotteryResultItem[] = [];
    public showPanel(keys: number[], isOne: boolean): void {
        this.show();
        if (isOne) {
            this.mBgImage.size = new mw.Vector(600, 200);
            this.mBgImage.position = new mw.Vector(this.rootCanvas.size.x / 2 - 300, this.rootCanvas.size.y / 2 - 100);
            this.mScrollBox.size = new mw.Vector(600, 75);
            this.mScrollBox.position = new mw.Vector(0, 75);
        } else {
            this.mBgImage.size = new mw.Vector(600, 850);
            this.mBgImage.position = new mw.Vector(this.rootCanvas.size.x / 2 - 300, this.rootCanvas.size.y / 2 - 425);
            this.mScrollBox.size = new mw.Vector(600, 750);
            this.mScrollBox.position = new mw.Vector(0, 75);
        }
        if (keys.length > this.lotteryResultItems.length) {
            for (let i = 0; i < this.lotteryResultItems.length; ++i) {
                this.lotteryResultItems[i].setTextBlock(keys[i]);
                Utils.setWidgetVisibility(this.lotteryResultItems[i].uiObject, mw.SlateVisibility.SelfHitTestInvisible);
            }
            for (let i = this.lotteryResultItems.length; i < keys.length; ++i) {
                let lotteryResultItem = mw.UIService.create(LotteryResultItem);
                lotteryResultItem.setTextBlock(keys[i]);
                this.mContentCanvas.addChild(lotteryResultItem.uiObject);
                this.lotteryResultItems.push(lotteryResultItem);
            }
        } else {
            for (let i = 0; i < keys.length; ++i) {
                this.lotteryResultItems[i].setTextBlock(keys[i]);
                Utils.setWidgetVisibility(this.lotteryResultItems[i].uiObject, mw.SlateVisibility.SelfHitTestInvisible);
            }
            for (let i = keys.length; i < this.lotteryResultItems.length; ++i) {
                Utils.setWidgetVisibility(this.lotteryResultItems[i].uiObject, mw.SlateVisibility.Collapsed);
            }
        }
    }
}

const lotteryTriggerMap: Map<number, { triggers: string[], worldUIIds: string[], name: string }> = new Map<number, { triggers: string[], worldUIIds: string[], name: string }>();
lotteryTriggerMap.set(1, { triggers: ["1784616E"], worldUIIds: ["0D23C019"], name: `Text_GoldCoinLottery` });
export class LotteryModuleC extends ModuleC<LotteryModuleS, null> {
    private lotteryPanel: LotteryPanel = null;
    private get getLotteryPanel(): LotteryPanel {
        if (!this.lotteryPanel) {
            this.lotteryPanel = mw.UIService.getUI(LotteryPanel);
        }
        return this.lotteryPanel;
    }

    private lotteryResultPanel: LotteryResultPanel = null;
    private get getLotteryResultPanel(): LotteryResultPanel {
        if (!this.lotteryResultPanel) {
            this.lotteryResultPanel = mw.UIService.getUI(LotteryResultPanel);
        }
        return this.lotteryResultPanel;
    }

    private hudModuleC: HUDModuleC = null;
    private get getHudModuleC(): HUDModuleC {
        if (!this.hudModuleC) {
            this.hudModuleC = ModuleService.getModule(HUDModuleC);
        }
        return this.hudModuleC;
    }

    private playerModuleC: PlayerModuleC = null;
    private get getPlayerModuleC(): PlayerModuleC {
        if (!this.playerModuleC) {
            this.playerModuleC = ModuleService.getModule(PlayerModuleC);
        }
        return this.playerModuleC;
    }

    private bagModuleC: BagModuleC = null;
    private get getBagModuleC(): BagModuleC {
        if (!this.bagModuleC) {
            this.bagModuleC = ModuleService.getModule(BagModuleC);
        }
        return this.bagModuleC;
    }

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        this.initUI();
        this.initAction();
    }

    protected onEnterScene(sceneType: number): void {
        this.initTrigger();
    }

    private initUI(): void {
        this.lotteryResultPanel = mw.UIService.getUI(LotteryResultPanel);
    }

    private initAction(): void {
        Event.addLocalListener(`UpdateCoinTextBlock`, this.addUpdateCoinTextBlock.bind(this));
        mw.PurchaseService.onArkBalanceUpdated.add(this.addArkUpdate.bind(this));
        this.getHudModuleC.onOpenLotteryAction.add(this.addOpenLotteryPanel.bind(this));
    }

    private addOpenLotteryPanel(): void {
        this.getLotteryPanel.show();
        mw.PurchaseService.getArkBalance(); // 触发代币余额刷新。接收更新的值要用mw.PurchaseService.onArkBalanceUpdated
        Event.dispatchToLocal(`SyncCoinCount`);
    }

    private addUpdateCoinTextBlock(count: number): void {
        this.getLotteryPanel.updateCoinTextBlock(count);
    }

    private addArkUpdate(amount: number): void {
        //刷新逻辑，amount为当前代币数量
        console.error(`ArkModuleC addArkUpdate amount: ${amount}`);
        this.getLotteryPanel.updateArkTextBlock(amount);
    }

    public oneCoinLottery(): void {
        let coin = this.getPlayerModuleC.getCoin();
        if (coin >= oneCostCoin) {
            this.getPlayerModuleC.saveCoin(-oneCostCoin);
            this.calculateOneLottery();
        } else {
            Notice.showDownNotice(GameConfig.Language.Text_InsufficientGoldCoins.Value);
            if (mw.SystemUtil.isPIE) {
                this.calculateOneLottery();
            } else {
                mw.PurchaseService.placeOrder(oneCommodityId, 1, (status, msg) => {
                    mw.PurchaseService.getArkBalance();//刷新代币数量
                });
            }
        }
    }

    public oneArkLottery(): void {
        if (mw.SystemUtil.isPIE) {
            this.calculateOneLottery();
        } else {
            mw.PurchaseService.placeOrder(oneCommodityId, 1, (status, msg) => {
                mw.PurchaseService.getArkBalance();//刷新代币数量
            });
        }
    }

    public tenCoinLottery(isTen: boolean): void {
        let coin = this.getPlayerModuleC.getCoin();
        let needCostCoin = isTen ? tenCostCoin : hundredCostCoin;
        if (coin >= needCostCoin) {
            this.getPlayerModuleC.saveCoin(-needCostCoin);
            this.calculateTenLottery(isTen);
        } else {
            Notice.showDownNotice(GameConfig.Language.Text_InsufficientGoldCoins.Value);
            if (mw.SystemUtil.isPIE) {
                this.calculateTenLottery(isTen);
            } else {
                mw.PurchaseService.placeOrder(isTen ? tenCommodityId : hundredCommodityId, 1, (status, msg) => {
                    mw.PurchaseService.getArkBalance();//刷新代币数量
                });
            }
        }
    }

    public tenArkLottery(isTen: boolean): void {
        if (mw.SystemUtil.isPIE) {
            this.calculateTenLottery(isTen);
        } else {
            mw.PurchaseService.placeOrder(isTen ? tenCommodityId : hundredCommodityId, 1, (status, msg) => {
                mw.PurchaseService.getArkBalance();//刷新代币数量
            });
        }
    }


    public net_deliverGoods(commodityId: string, amount: number): void {
        if (commodityId == oneCommodityId) {
            this.calculateOneLottery();
        } else if (commodityId == tenCommodityId) {
            this.calculateTenLottery(true);
        } else if (commodityId == hundredCommodityId) {
            this.calculateTenLottery(false);
        }
    }

    public calculateOneLottery(): void {
        let calculateKey = this.calculateKey();
        while ((lotteryDatas.get(calculateKey).isLimit) && this.isHas(lotteryDatas.get(calculateKey).reward)) {
            calculateKey = this.calculateKey();
        }
        let diamond: number = 0;
        let lv: number = 0;
        let bagIds: number[] = [];
        switch (lotteryDatas.get(calculateKey).rewardType) {
            case RewardType.None:
                break;
            case RewardType.Diamond:
                diamond = lotteryDatas.get(calculateKey).reward;
                break;
            case RewardType.Lv:
                lv = lotteryDatas.get(calculateKey).reward;
                break;
            case RewardType.Bag:
                let bagId = lotteryDatas.get(calculateKey).reward;
                bagIds.push(bagId);
                break;
        }
        this.getLotteryPanel.startOneLottery(calculateKey, () => {
            this.saveLottery(diamond, lv, bagIds);
            this.getLotteryResultPanel.showPanel([calculateKey], true);
            if (lotteryDatas.get(calculateKey).isLimit) this.getLotteryPanel.updateItemHasState(calculateKey);
            Notice.showDownNotice(GameConfig.Language.Text_CongratulationsOnWinningThePrize.Value);
        });
    }

    private calculateTenLottery(isTen: boolean): void {
        let diamond: number = 0;
        let lv: number = 0;
        let bagIds: number[] = [];
        let calculateKeys: number[] = [];

        let len = isTen ? 10 : 100;

        for (let i = 0; i < len; ++i) {
            let calculateKey = this.calculateKey();
            while ((lotteryDatas.get(calculateKey).isLimit) &&
                (this.isHas(lotteryDatas.get(calculateKey).reward) || bagIds.includes(lotteryDatas.get(calculateKey).reward))) {
                calculateKey = this.calculateKey();
            }
            calculateKeys.push(calculateKey);
            switch (lotteryDatas.get(calculateKey).rewardType) {
                case RewardType.None:
                    break;
                case RewardType.Diamond:
                    diamond += lotteryDatas.get(calculateKey).reward;
                    break;
                case RewardType.Lv:
                    lv += lotteryDatas.get(calculateKey).reward;
                    break;
                case RewardType.Bag:
                    let bagId = lotteryDatas.get(calculateKey).reward;
                    bagIds.push(bagId);
                    break;
            }
        }
        this.getLotteryPanel.startTenLottery(calculateKeys, () => {
            this.saveLottery(diamond, lv, bagIds);
            this.getLotteryResultPanel.showPanel(calculateKeys, false);
            calculateKeys.forEach((key: number) => {
                if (lotteryDatas.get(key).isLimit) this.getLotteryPanel.updateItemHasState(key);
            });
            Notice.showDownNotice(GameConfig.Language.Text_CongratulationsOnWinningThePrize.Value);
        });
    }

    private calculateKey(): number {
        let calculateValue = Utils.getRandomInteger(1, 1000);
        let calculateKey: number = 1;
        lotteryDatas.forEach((value: {
            isLimit: boolean;
            ratio: number[];
            icon: string;
            name: string;
            rewardType: RewardType;
            reward: number;
            pos: mw.Vector2;
            bgIcon: string;
        }, key: number) => {
            if (calculateValue >= value.ratio[0] && calculateValue <= value.ratio[1]) {
                calculateKey = key;
            }
        });
        return calculateKey;
    }

    private saveLottery(diamond: number, lv: number, bagIds: number[]): void {
        if (diamond > 0) {
            Notice.showDownNotice(StringUtil.format(GameConfig.Language.Text_ObtainDiamonds.Value, diamond));
            this.getPlayerModuleC.saveDiamond(diamond);
        }

        if (lv > 0) {
            this.getPlayerModuleC.upLvByCount(lv);
            Notice.showDownNotice(`${GameConfig.Language.Text_Grade.Value}+${lv}`);
        }

        if (bagIds && bagIds.length > 0) {
            for (let i = 0; i < bagIds.length; ++i) {
                this.getBagModuleC.setBagId(bagIds[i]);
            }
            Notice.showDownNotice(GameConfig.Language.Text_OpenTheBackpackForUse.Value);
        }
    }

    public isHas(key: number): boolean {
        return this.getBagModuleC.isHasBagId(key);
    }

    private initTrigger(): void {
        lotteryTriggerMap.forEach((value: {
            triggers: string[];
            worldUIIds: string[];
            name: string;
        }, key: number) => {
            value.triggers.forEach((triggerId: string) => {
                mw.GameObject.asyncFindGameObjectById(triggerId).then((go: mw.GameObject) => {
                    let trigger = go as mw.Trigger;
                    trigger.onEnter.add((character: mw.Character) => {
                        if (character.gameObjectId != this.localPlayer.character.gameObjectId) return;
                        this.getLotteryPanel.show();
                    });
                });
            });
            value.worldUIIds.forEach((worldId: string) => {
                mw.GameObject.asyncFindGameObjectById(worldId).then((v: mw.GameObject) => {
                    let worldUI: mw.UIWidget = v as mw.UIWidget;
                    let levelItem = mw.UIService.create(LevelItem);
                    levelItem.updateLevelTextBlock(GameConfig.Language[`${value.name}`].Value);
                    worldUI.setTargetUIWidget(levelItem.uiWidgetBase);
                });
            });
        });
    }
}

export class LotteryModuleS extends ModuleS<LotteryModuleC, null> {

    /** 当脚本被实例后，会在第一帧更新前调用此函数 */
    protected onStart(): void {
        this.bindAction();
    }

    private bindAction(): void {
        mw.PurchaseService.onOrderDelivered.add(this.addShipOrder.bind(this));
    }

    private addShipOrder(playerId: number, orderId: string, commodityId: string, amount: number, confirmOrder: (bReceived: boolean) => void): void {
        //根据playerId和commodityId来处理购买逻辑
        this.getClient(playerId).net_deliverGoods(commodityId, amount);
        confirmOrder(true);//调用这个方法表示确认收货成功
    }
}