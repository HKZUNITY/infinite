import GlobalData from "../../const/GlobalData";
import Console from "../../Tools/Console";
import { Utils } from "../../Tools/utils";

export default class PlayerData extends Subdata {
    @Decorator.persistence()
    public exp: number = 0;

    @Decorator.persistence()
    public coin: number = 0;

    @Decorator.persistence()
    public diamond: number = 0;

    @Decorator.persistence()
    public bone: number = 0;

    @Decorator.persistence()
    public playerLv: number = 0;

    @Decorator.persistence()
    public playerHeight: number = 0;

    @Decorator.persistence()
    public playerKill: number = 0;

    @Decorator.persistence()
    public dayStr: string = "";

    @Decorator.persistence()
    public titleName: string = "";

    protected initDefaultData(): void {
        this.exp = 0;
        this.coin = 28888888;
        this.diamond = 10000;
        this.bone = 10000;

        this.playerLv = 90;
        this.playerHeight = 0;
        this.playerKill = 0;
        Console.error("AAA");
    }

    public saveCoinAndExp(coin: number, exp: number): void {
        this.saveCoin(coin, false);
        this.addExp(exp);
        this.save(true);
    }

    public saveExpAndCoin(value: number): void {
        this.saveCoin(value, false);
        this.addExp(value);
        this.save(true);
    }

    public addExp(exp: number): void {
        this.exp += exp;
        this.checkLvUp();
    }

    private checkLvUp(): void {
        while (true) {
            const lvUpExp = this.getLvUpExp();
            if (this.exp < lvUpExp) break;
            this.exp -= lvUpExp;
            this.playerLv++;
        }
    }

    public getLvUpExp(): number {
        return (this.playerLv + 1) * GlobalData.upgradeExpMultiple;
    }

    public saveCoin(value: number, isAutoSave: boolean = true): void {
        this.coin += value;
        if (isAutoSave) this.save(true);
    }

    public saveDiamond(value: number): void {
        this.diamond += value;
        this.save(true);
    }

    public refashLv(lv: number) {
        this.playerLv += lv;
        this.save(true);
    }

    public refashHeight(height: number) {
        this.playerHeight = height;
        this.save(true);
    }

    public refashKill(kill: number) {
        this.playerKill += kill;
        this.save(true);
    }

    public getHp(): number {
        return Utils.getHp(this.playerLv);
    }

    public saveBone(bone: number): void {
        this.bone += bone;
        this.save(true);
    }

    public getBone(bone: number = 0): number {
        if (bone != 0) {
            this.bone += bone;
            this.save(true);
        }
        return this.bone;
    }

    public setDayStr(dayStr: string): void {
        this.dayStr = dayStr;
        this.save(true);
    }

    public setTitleName(titleName: string): void {
        this.titleName = titleName;
        this.save(false);
    }

    public get getTitleName(): string {
        return this.titleName;
    }
}